
jQuery UI Dialog Options v1.0
=================

Additional options/functionality for jQuery UI Dialog.

New Options:
*	clickOut: true		    // closes dialog when clicked outside
*	responsive: true	    // fluid width & height based on viewport
*	showTitleBar: true	  // hide titlebar when false
*	showCloseButton: true	// hide close button when false

Added functionality:
*	add & remove dialogClass to .ui-widget-overlay for scoping styles
*	patch for: http://bugs.jqueryui.com/ticket/4671 - fixed in UI v1.10


Demo:
http://jsfiddle.net/jasonday/nWcFR/


Changelog:

1/22/2014 - Initial commit
